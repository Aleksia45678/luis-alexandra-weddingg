import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import {
  Heart,
  GlassWater,
  Clock,
  MapPin,
  Info,
  Utensils,
  UserCheck,
  Crown,
  Menu,
  X,
  CheckCircle,
} from "lucide-react";

// EmailJS configuration
declare global {
  interface Window {
    emailjs: any;
  }
}

const rsvpSchema = z.object({
  name: z.string().min(1, "Имя обязательно"),
  email: z.string().email("Некорректный email"),
  attendance: z.enum([
    "ceremony-only",
    "reception-only",
    "both",
    "cannot-attend",
    "unknown",
  ]),
  alcohol: z.array(z.string()).optional(),
  alcoholOther: z.string().optional(),
  alcoholQuantity: z.string().optional(),
  nonAlcoholic: z.array(z.string()).optional(),
  nonAlcoholicOther: z.string().optional(),
  nonAlcoholicQuantity: z.string().optional(),
  dietaryRestrictions: z.string().optional(),
  wishes: z.string().optional(),
});

type RSVPFormData = z.infer<typeof rsvpSchema>;

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: { errors },
  } = useForm<RSVPFormData>({
    resolver: zodResolver(rsvpSchema),
    defaultValues: {
      alcohol: [],
      nonAlcoholic: [],
    },
  });

  const attendance = watch("attendance");
  const alcoholChoices = watch("alcohol") || [];
  const nonAlcoholicChoices = watch("nonAlcoholic") || [];

  useEffect(() => {
    // Initialize EmailJS
    if (window.emailjs) {
      window.emailjs.init("6ZgOQGKuxgqTHGkxd");
    }
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  const handleAlcoholChange = (value: string, checked: boolean) => {
    const current = alcoholChoices;
    if (checked) {
      setValue("alcohol", [...current, value]);
    } else {
      setValue(
        "alcohol",
        current.filter((v) => v !== value),
      );
      if (value === "other") {
        setValue("alcoholOther", "");
      }
    }
  };

  const handleNonAlcoholicChange = (value: string, checked: boolean) => {
    const current = nonAlcoholicChoices;
    if (checked) {
      setValue("nonAlcoholic", [...current, value]);
    } else {
      setValue(
        "nonAlcoholic",
        current.filter((v) => v !== value),
      );
      if (value === "other") {
        setValue("nonAlcoholicOther", "");
      }
    }
  };

  const onSubmit = async (data: RSVPFormData) => {
    setIsSubmitting(true);

    try {
      // Prepare email template parameters
      const alcoholText = data.alcohol?.join(", ") || "Не указано";
      const alcoholWithOther =
        alcoholText +
        (data.alcoholOther ? ` (Другое: ${data.alcoholOther})` : "");

      const nonAlcoholicText = data.nonAlcoholic?.join(", ") || "Не указано";
      const nonAlcoholicWithOther =
        nonAlcoholicText +
        (data.nonAlcoholicOther ? ` (Другое: ${data.nonAlcoholicOther})` : "");

      const templateParams = {
        name: data.name,
        email: data.email,
        message: `
RSVP ответ на свадьбу Луиса и Александры

Имя: ${data.name}
Email: ${data.email}
Участие: ${getAttendanceText(data.attendance)}

Алкогольные напитки: ${alcoholWithOther}
Количество алкоголя: ${getAlcoholQuantityText(data.alcoholQuantity)}

Безалкогольные напитки: ${nonAlcoholicWithOther}
Количество безалкогольных: ${getNonAlcoholicQuantityText(data.nonAlcoholicQuantity)}

Диетические ограничения: ${data.dietaryRestrictions || "Нет"}
Пожелания: ${data.wishes || "Нет"}

---
Отправлено с сайта приглашения на свадьбу
        `.trim(),
      };

      // Send email using EmailJS
      const result = await window.emailjs.send(
        "service_1ppu95j",
        "template_axzk81j",
        templateParams,
      );

      console.log("Email sent successfully:", result);

      setShowSuccessModal(true);
      reset();
      toast({
        title: "Спасибо!",
        description: "Ваш ответ успешно отправлен на почту.",
      });
    } catch (error) {
      console.error("Error sending email:", error);
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при отправке. Попробуйте еще раз.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getAttendanceText = (value?: string) => {
    const map: Record<string, string> = {
      "ceremony-only": "Только церемония",
      "reception-only": "Банкет",
      both: "Банкет и церемония",
      "cannot-attend": "К сожалению, не смогу/сможем присутствовать",
      unknown: "Пока не знаю",
    };
    return map[value || ""] || "Не указано";
  };

  const getAlcoholQuantityText = (value?: string) => {
    const map: Record<string, string> = {
      "less-than-one": "Меньше 1 бутылки",
      "one-bottle": "1 бутылка",
      "more-than-one": "Больше 1 бутылки",
    };
    return map[value || ""] || "Не указано";
  };

  const getNonAlcoholicQuantityText = (value?: string) => {
    const map: Record<string, string> = {
      "only-non-alcoholic": "Буду только безалкоголь",
      "less-than-one": "Менее 1 бутылки",
      "one-bottle": "1 бутылка",
      "more-than-one": "Более 1 бутылки",
    };
    return map[value || ""] || "Не указано";
  };

  return (
    <div className="min-h-screen bg-cream">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/90 backdrop-blur-sm z-50 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="font-display text-2xl font-bold text-champagne">
              Л & А
            </div>
            <div className="hidden md:flex space-x-8">
              <button
                onClick={() => scrollToSection("home")}
                className="text-charcoal hover:text-champagne transition-colors font-medium"
              >
                Главная
              </button>
              <button
                onClick={() => scrollToSection("details")}
                className="text-charcoal hover:text-champagne transition-colors font-medium"
              >
                Детали
              </button>
              <button
                onClick={() => scrollToSection("dresscode")}
                className="text-charcoal hover:text-champagne transition-colors font-medium"
              >
                Дресс-код
              </button>
              <button
                onClick={() => scrollToSection("rsvp")}
                className="text-charcoal hover:text-champagne transition-colors font-medium"
              >
                RSVP
              </button>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden text-charcoal"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X /> : <Menu />}
            </Button>
          </div>
          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden mt-4 pb-4 border-t border-gray-200">
              <div className="flex flex-col space-y-3 mt-4">
                <button
                  onClick={() => scrollToSection("home")}
                  className="text-left text-charcoal hover:text-champagne transition-colors font-medium"
                >
                  Главная
                </button>
                <button
                  onClick={() => scrollToSection("details")}
                  className="text-left text-charcoal hover:text-champagne transition-colors font-medium"
                >
                  Детали
                </button>
                <button
                  onClick={() => scrollToSection("dresscode")}
                  className="text-left text-charcoal hover:text-champagne transition-colors font-medium"
                >
                  Дресс-код
                </button>
                <button
                  onClick={() => scrollToSection("rsvp")}
                  className="text-left text-charcoal hover:text-champagne transition-colors font-medium"
                >
                  RSVP
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section
        id="home"
        className="min-h-screen flex items-center justify-center relative"
      >
        <div
          className="absolute inset-0 bg-cover bg-center bg-fixed"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1519225421980-715cb0215aed?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          }}
        />
        <div className="absolute inset-0 bg-white/70" />

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <p className="text-lg md:text-xl font-light text-charcoal mb-8 tracking-wide">
            Мы приглашаем вас разделить с нами этот особенный день!
          </p>

          <div className="mb-12">
            <h1 className="font-display text-5xl md:text-7xl font-bold text-champagne mb-4">
              Луис
            </h1>
            <div className="flex items-center justify-center mb-4">
              <div className="w-16 h-px bg-champagne" />
              <span className="mx-4 text-3xl md:text-4xl text-champagne">
                &
              </span>
              <div className="w-16 h-px bg-champagne" />
            </div>
            <h1 className="font-display text-5xl md:text-7xl font-bold text-champagne">
              Александра
            </h1>
          </div>

          <Card className="bg-white/80 backdrop-blur-sm shadow-lg inline-block mb-8">
            <CardContent className="p-6">
              <p className="text-2xl md:text-3xl font-display font-semibold text-charcoal mb-2">
                22 августа 2025
              </p>
              <p className="text-lg text-charcoal/80">Пятница</p>
              <div className="mt-4">
                <Heart className="text-champagne mx-auto" size={32} />
              </div>
            </CardContent>
          </Card>

          <div>
            <Button
              onClick={() => scrollToSection("details")}
              className="bg-[#da33ff] hover:bg-[#da33ff]/90 text-white px-8 py-3 rounded-full font-medium transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              Узнать подробности
            </Button>
          </div>
        </div>
      </section>

      {/* Wedding Details */}
      <section
        id="details"
        className="py-20 bg-gradient-to-b from-cream to-white"
      >
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-charcoal mb-6">
              Детали свадьбы
            </h2>
            <p className="text-lg md:text-xl text-charcoal/80 max-w-3xl mx-auto leading-relaxed">
              Присоединяйтесь к нам в этот особенный день, когда мы начинаем
              наше путешествие как муж и жена
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Ceremony Card */}
            <Card className="hover:shadow-xl transition-shadow duration-300">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-blush rounded-full flex items-center justify-center mx-auto mb-4">
                    <Heart className="text-champagne" size={32} />
                  </div>
                  <h3 className="font-display text-2xl font-bold text-charcoal mb-2">
                    Церемония
                  </h3>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center text-charcoal">
                    <Clock className="text-champagne mr-3" size={20} />
                    <span className="font-semibold">09:00</span>
                  </div>
                  <div className="flex items-start text-charcoal">
                    <MapPin
                      className="text-champagne mr-3 mt-1 flex-shrink-0"
                      size={20}
                    />
                    <div>
                      <p className="font-semibold">ЗАГС Всеволожск</p>
                      <p className="text-sm text-charcoal/70 mt-1">
                        Управление ЗАГС администрации муниципального образования
                        Всеволожский муниципальный район Ленинградской области
                      </p>
                      <p className="text-sm text-charcoal/70">
                        Александровская ул., 74, Всеволожск
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center text-charcoal">
                    <Info className="text-champagne mr-3" size={20} />
                    <span className="text-sm">Официальная регистрация</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Reception Card */}
            <Card className="hover:shadow-xl transition-shadow duration-300">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-lavender rounded-full flex items-center justify-center mx-auto mb-4">
                    <GlassWater className="text-champagne" size={32} />
                  </div>
                  <h3 className="font-display text-2xl font-bold text-charcoal mb-2">
                    Банкет
                  </h3>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center text-charcoal">
                    <Clock className="text-champagne mr-3" size={20} />
                    <span className="font-semibold">16:00 - 21:00</span>
                  </div>
                  <div className="flex items-start text-charcoal">
                    <MapPin
                      className="text-champagne mr-3 mt-1 flex-shrink-0"
                      size={20}
                    />
                    <div>
                      <p className="font-semibold">Место уточняется</p>
                      <p className="text-sm text-charcoal/70 mt-1">
                        Подробности будут сообщены дополнительно
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center text-charcoal">
                    <Utensils className="text-champagne mr-3" size={20} />
                    <span className="text-sm">Ужин, танцы и веселье</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Dress Code */}
      <section
        id="dresscode"
        className="py-20 bg-gradient-to-b from-white to-blush"
      >
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-charcoal mb-6">
              Дресс-код
            </h2>
            <p className="text-lg text-charcoal/80 max-w-2xl mx-auto">
              Мы просим вас одеться элегантно. Пожалуйста, избегайте белого и
              красного цвета.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Men's Dress Code */}
            <Card className="shadow-lg text-center">
              <CardContent className="p-8">
                <div className="w-20 h-20 bg-sage rounded-full flex items-center justify-center mx-auto mb-6">
                  <UserCheck className="text-champagne" size={40} />
                </div>
                <h3 className="font-display text-2xl font-bold text-charcoal mb-4">
                  Мужчины
                </h3>
                <p className="text-charcoal/80 leading-relaxed">
                  Костюм / джинсы с рубашкой,
                  <br />
                  можно кроссовки нейтрального цвета
                </p>
              </CardContent>
            </Card>

            {/* Women's Dress Code */}
            <Card className="shadow-lg text-center">
              <CardContent className="p-8">
                <div className="w-20 h-20 bg-blush rounded-full flex items-center justify-center mx-auto mb-6">
                  <Crown className="text-champagne" size={40} />
                </div>
                <h3 className="font-display text-2xl font-bold text-charcoal mb-4">
                  Женщины
                </h3>
                <p className="text-charcoal/80 leading-relaxed">
                  Коктейльное платье
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* RSVP Form */}
      <section
        id="rsvp"
        className="py-20 bg-gradient-to-b from-blush to-lavender"
      >
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-charcoal mb-6">
              Подтвердите участие
            </h2>
            <p className="text-lg text-charcoal/80">
              Пожалуйста, ответьте до 30 июля 2025 года
            </p>
          </div>

          <Card className="shadow-xl">
            <CardContent className="p-8">
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                {/* Basic Info */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label
                      htmlFor="name"
                      className="text-charcoal font-semibold"
                    >
                      Имя *
                    </Label>
                    <Input
                      id="name"
                      {...register("name")}
                      className="mt-2"
                      placeholder="Ваше имя"
                    />
                    {errors.name && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.name.message}
                      </p>
                    )}
                  </div>
                  <div>
                    <Label
                      htmlFor="email"
                      className="text-charcoal font-semibold"
                    >
                      Email *
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      {...register("email")}
                      className="mt-2"
                      placeholder="your@email.com"
                    />
                    {errors.email && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.email.message}
                      </p>
                    )}
                  </div>
                </div>

                {/* Attendance */}
                <div>
                  <Label className="text-charcoal font-semibold mb-4 block">
                    Сможете присутствовать? *
                  </Label>
                  <RadioGroup
                    value={attendance}
                    onValueChange={(value) =>
                      setValue("attendance", value as any)
                    }
                    className="space-y-3"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem
                        value="ceremony-only"
                        id="ceremony-only"
                      />
                      <Label htmlFor="ceremony-only">Только церемония</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem
                        value="reception-only"
                        id="reception-only"
                      />
                      <Label htmlFor="reception-only">Банкет</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="both" id="both" />
                      <Label htmlFor="both">Банкет и церемония</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem
                        value="cannot-attend"
                        id="cannot-attend"
                      />
                      <Label htmlFor="cannot-attend">
                        К сожалению, не смогу/сможем присутствовать
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="unknown" id="unknown" />
                      <Label htmlFor="unknown">Пока не знаю</Label>
                    </div>
                  </RadioGroup>
                  {errors.attendance && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.attendance.message}
                    </p>
                  )}
                </div>

                {/* Alcohol Preferences - Only show if not "cannot-attend" */}
                {attendance && attendance !== "cannot-attend" && (
                  <>
                    <div>
                      <Label className="text-charcoal font-semibold mb-4 block">
                        Какой алкоголь вы будете пить? *
                      </Label>
                      <div className="grid md:grid-cols-2 gap-3">
                        {[
                          { value: "wine", label: "Вино" },
                          { value: "champagne", label: "Шампанское" },
                          { value: "whiskey", label: "Виски" },
                          { value: "vodka", label: "Водка" },
                          { value: "none", label: "Не пью алкоголь" },
                          { value: "other", label: "Другое" },
                        ].map((option) => (
                          <div
                            key={option.value}
                            className="flex items-center space-x-2"
                          >
                            <Checkbox
                              id={`alcohol-${option.value}`}
                              checked={alcoholChoices.includes(option.value)}
                              onCheckedChange={(checked) =>
                                handleAlcoholChange(
                                  option.value,
                                  checked as boolean,
                                )
                              }
                            />
                            <Label htmlFor={`alcohol-${option.value}`}>
                              {option.label}
                            </Label>
                          </div>
                        ))}
                      </div>
                      {alcoholChoices.includes("other") && (
                        <Input
                          {...register("alcoholOther")}
                          className="mt-3"
                          placeholder="Укажите другой алкоголь"
                        />
                      )}
                    </div>

                    {/* Alcohol Quantity */}
                    <div>
                      <Label className="text-charcoal font-semibold mb-4 block">
                        Сколько алкоголя планируете выпить?
                      </Label>
                      <RadioGroup
                        onValueChange={(value) =>
                          setValue("alcoholQuantity", value)
                        }
                        className="space-y-3"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem
                            value="less-than-one"
                            id="alc-less-than-one"
                          />
                          <Label htmlFor="alc-less-than-one">
                            Меньше 1 бутылки
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem
                            value="one-bottle"
                            id="alc-one-bottle"
                          />
                          <Label htmlFor="alc-one-bottle">1 бутылка</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem
                            value="more-than-one"
                            id="alc-more-than-one"
                          />
                          <Label htmlFor="alc-more-than-one">
                            Больше 1 бутылки
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>
                  </>
                )}

                {/* Non-alcoholic Drinks */}
                <div>
                  <Label className="text-charcoal font-semibold mb-4 block">
                    Будете ли пить безалкогольные напитки?
                  </Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    {[
                      { value: "mors", label: "Морс" },
                      { value: "cola", label: "Кола" },
                      { value: "tea", label: "Чай" },
                      { value: "other", label: "Другое" },
                    ].map((option) => (
                      <div
                        key={option.value}
                        className="flex items-center space-x-2"
                      >
                        <Checkbox
                          id={`non-alc-${option.value}`}
                          checked={nonAlcoholicChoices.includes(option.value)}
                          onCheckedChange={(checked) =>
                            handleNonAlcoholicChange(
                              option.value,
                              checked as boolean,
                            )
                          }
                        />
                        <Label htmlFor={`non-alc-${option.value}`}>
                          {option.label}
                        </Label>
                      </div>
                    ))}
                  </div>
                  {nonAlcoholicChoices.includes("other") && (
                    <Input
                      {...register("nonAlcoholicOther")}
                      className="mt-3"
                      placeholder="Укажите другие безалкогольные напитки"
                    />
                  )}
                </div>

                {/* Non-alcoholic Quantity */}
                <div>
                  <Label className="text-charcoal font-semibold mb-4 block">
                    Сколько безалкогольных напитков вам нужно?
                  </Label>
                  <RadioGroup
                    onValueChange={(value) =>
                      setValue("nonAlcoholicQuantity", value)
                    }
                    className="space-y-3"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem
                        value="only-non-alcoholic"
                        id="only-non-alcoholic"
                      />
                      <Label htmlFor="only-non-alcoholic">
                        Буду только безалкоголь
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem
                        value="less-than-one"
                        id="non-alc-less-than-one"
                      />
                      <Label htmlFor="non-alc-less-than-one">
                        Менее 1 бутылки
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem
                        value="one-bottle"
                        id="non-alc-one-bottle"
                      />
                      <Label htmlFor="non-alc-one-bottle">1 бутылка</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem
                        value="more-than-one"
                        id="non-alc-more-than-one"
                      />
                      <Label htmlFor="non-alc-more-than-one">
                        Более 1 бутылки
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                {/* Dietary Restrictions */}
                <div>
                  <Label
                    htmlFor="dietaryRestrictions"
                    className="text-charcoal font-semibold"
                  >
                    Диетические ограничения
                  </Label>
                  <Textarea
                    id="dietaryRestrictions"
                    {...register("dietaryRestrictions")}
                    className="mt-2"
                    rows={3}
                    placeholder="Пожалуйста, укажите любые диетические ограничения или аллергии"
                  />
                </div>

                {/* Wishes */}
                <div>
                  <Label
                    htmlFor="wishes"
                    className="text-charcoal font-semibold"
                  >
                    Пожелания
                  </Label>
                  <Textarea
                    id="wishes"
                    {...register("wishes")}
                    className="mt-2"
                    rows={3}
                    placeholder="Поделитесь своими пожеланиями или вопросами"
                  />
                </div>

                {/* Submit Button */}
                <div className="text-center pt-6">
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-champagne hover:bg-champagne/90 text-white px-12 py-4 rounded-full font-semibold text-lg transition-all duration-300 shadow-lg hover:shadow-xl"
                  >
                    {isSubmitting
                      ? "Отправляется..."
                      : "Отправить подтверждение"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-charcoal text-white py-12">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="font-display text-3xl font-bold text-champagne mb-4">
            Луис & Александра
          </div>
          <p className="text-white/80 mb-6">
            Спасибо, что станете частью нашего особенного дня!
          </p>
          <p className="text-white/60 text-sm">
            © 2025 Свадьба Луиса и Александры. Создано с любовью.
          </p>
        </div>
      </footer>

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="max-w-md mx-4">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="text-green-600" size={32} />
              </div>
              <h3 className="font-display text-2xl font-bold text-charcoal mb-2">
                Спасибо!
              </h3>
              <p className="text-charcoal/80 mb-6">
                Ваш ответ успешно отправлен. Мы свяжемся с вами в ближайшее
                время.
              </p>
              <Button
                onClick={() => setShowSuccessModal(false)}
                className="bg-champagne hover:bg-champagne/90 text-white px-6 py-2 rounded-full font-medium transition-all"
              >
                Закрыть
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
