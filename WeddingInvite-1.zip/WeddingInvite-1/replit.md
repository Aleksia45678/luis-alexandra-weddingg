# Wedding RSVP Application

## Overview

This is a wedding RSVP application built with a modern full-stack architecture. The application allows guests to RSVP for a wedding celebration, providing details about attendance, dietary preferences, and beverage selections. The frontend is a Russian-language wedding invitation site for Luis and Alexandra's wedding on August 22, 2025.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between client and server code:

- **Frontend**: React with TypeScript, using Vite for development and build tooling
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **UI Framework**: shadcn/ui components built on Radix UI primitives with Tailwind CSS
- **Styling**: Tailwind CSS with custom wedding theme colors and typography
- **Form Handling**: React Hook Form with Zod validation
- **Email Service**: EmailJS for sending RSVP notifications

## Key Components

### Frontend Architecture
- **React Router**: Using Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management
- **Form Management**: React Hook Form with Zod schema validation
- **UI Components**: Complete shadcn/ui component library with custom wedding theming
- **Responsive Design**: Mobile-first approach with Tailwind CSS

### Backend Architecture
- **Express Server**: RESTful API structure with TypeScript
- **Database Layer**: Drizzle ORM with PostgreSQL dialect
- **Storage Interface**: Abstracted storage layer with in-memory implementation for development
- **Error Handling**: Centralized error handling middleware
- **Development Tools**: Hot reload with tsx, Vite integration for serving static files

### Database Schema
- **Users Table**: Basic user management with username/password authentication
- **Migrations**: Drizzle-based migration system for schema versioning

## Data Flow

1. **Client Requests**: React frontend makes API calls through TanStack Query
2. **Server Processing**: Express routes handle business logic and database operations
3. **Database Operations**: Drizzle ORM provides type-safe database interactions
4. **Response Handling**: Standardized JSON responses with error handling
5. **Email Notifications**: EmailJS integration for sending RSVP confirmations

## External Dependencies

### Core Technologies
- **@neondatabase/serverless**: Serverless PostgreSQL driver
- **drizzle-orm**: Type-safe ORM with Zod integration
- **@tanstack/react-query**: Server state management
- **react-hook-form**: Form handling with validation
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **Vite**: Frontend build tool and development server
- **tsx**: TypeScript execution for development
- **esbuild**: Production build bundling

### Email Service
- **EmailJS**: Client-side email service for RSVP notifications

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx with nodemon-like behavior for TypeScript execution
- **Database**: Environment variable configuration for connection

### Production
- **Build Process**: 
  - Frontend: Vite build to `dist/public`
  - Backend: esbuild bundle to `dist/index.js`
- **Server**: Node.js with Express serving both API and static files
- **Database**: PostgreSQL with connection pooling via Neon serverless driver

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **NODE_ENV**: Environment detection for development/production behaviors
- **REPL_ID**: Replit-specific development features

The application is designed to be easily deployable on platforms like Replit, with automatic detection of development vs production environments and appropriate tooling integration.